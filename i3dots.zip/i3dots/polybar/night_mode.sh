#!/bin/bash

MONITOR="DVI-D-0"

# Получаем текущую яркость из xrandr
CURRENT_BRIGHTNESS=$(xrandr --verbose | grep -A 5 "$MONITOR" | grep "Brightness" | awk '{print $2}')

if [ -z "$CURRENT_BRIGHTNESS" ]; then
    CURRENT_BRIGHTNESS=1.0
fi

case "$1" in
    up)
        # Прибавляем 0.1, но не выше 1.0
        NEW_BRIGHTNESS=$(echo "$CURRENT_BRIGHTNESS + 0.1" | bc)
        if (( $(echo "$NEW_BRIGHTNESS > 1.0" | bc -l) )); then NEW_BRIGHTNESS="1.0"; fi
        xrandr --output "$MONITOR" --brightness "$NEW_BRIGHTNESS"
        ;;
    down)
        # Убавляем 0.1, но не ниже 0.1
        NEW_BRIGHTNESS=$(echo "$CURRENT_BRIGHTNESS - 0.1" | bc)
        if (( $(echo "$NEW_BRIGHTNESS < 0.1" | bc -l) )); then NEW_BRIGHTNESS="0.1"; fi
        xrandr --output "$MONITOR" --brightness "$NEW_BRIGHTNESS"
        ;;
    click)
        # При клике: если 1.0 — роняем до 0.3, если меньше 1.0 — возвращаем на 1.0
        if (( $(echo "$CURRENT_BRIGHTNESS == 1.0" | bc -l) )); then
            xrandr --output "$MONITOR" --brightness 0.3
        else
            xrandr --output "$MONITOR" --brightness 1.0
        fi
        ;;
esac

# Вывод на панель Polybar
if (( $(echo "$CURRENT_BRIGHTNESS < 1.0" | bc -l) )); then
    PERCENT=$(echo "$CURRENT_BRIGHTNESS * 100" | bc | cut -d'.' -f1)
    echo "󰖔 ${PERCENT}%"
else
    echo "󰖙"
fi
