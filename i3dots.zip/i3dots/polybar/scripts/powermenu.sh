#!/usr/bin/env bash

# Вызываем rofi для выбора действия
chosen=$(echo -e " Завершение работы\n Перезагрузка\n Сон\n󰗼 Выход из системы" | rofi -dmenu -i -p "Действие:")

case "$chosen" in
    " Завершение работы")
        loginctl poweroff
        ;;
    " Перезагрузка")
        loginctl reboot
        ;;
    " Сон")
        # В Artix с OpenRC обычно используется zzz
        loginctl suspend
        ;;
    "󰗼 Выход из системы")
        i3-msg exit
        ;;
esac
