#!/bin/bash

# Достаем все окна, которые находятся на скрытом воркспейсе __i3_scratch
LIST=$(i3-msg -t get_tree | jq -r '.nodes[].nodes[].nodes[] | select(.name == "__i3_scratch") | .. | select(.window? != null) | "\(.id): \(.name)"')

# Если там пусто, пробуем альтернативный (более глубокий) путь парсинга
if [ -z "$LIST" ]; then
    LIST=$(i3-msg -t get_tree | jq -r '.. | select(.name? == "__i3_scratch") | .. | select(.window? != null) | "\(.id): \(.name)"')
fi

# Если и так пусто — значит в скретчпаде реально ничего нет
if [ -z "$LIST" ]; then
    echo "Скретчпад пуст!" # Чтобы в терминале было видно, что скрипт отработал
    exit 0
fi

# Вызываем Rofi
CHOICE=$(echo "$LIST" | rofi -dmenu -p "Развернуть" -theme-str 'configuration { show-icons: false; }')

# Разворачиваем окно, если пользователь его выбрал
if [ -n "$CHOICE" ]; then
    WIN_ID=$(echo "$CHOICE" | grep -o '^[0-9]\+')
    i3-msg "[con_id=\"$WIN_ID\"] scratchpad show"
fi
